# Paired fault detector benchmark

Artificial dimensionless software fixture; no physiological calibration, biological prediction or machine-control output.

Each injected event is a separate run. A detection requires the first confirmation inside the inclusive fault window and strictly before any confirmation in its paired control. All other events count as missed. Delay is measured from onset to confirmation in dimensionless time and summarized only for detections. Each control with any confirmation counts as one false alarm.

Fit a shared multiplier for all three thresholds on no-fault controls. Hold both sensor thresholds at that fit and try each actuator multiplier on the same controls. Each stage uses the complete balance-augmented detector and selects the smallest candidate with zero alarms, or the largest candidate if all alarm. Evaluate both fits on the same fresh noise streams and fault timings. The confirmation count stays fixed.

Candidate factors were 1, 2, 4, with 12 controls per candidate.

| Noise multiplier | Detector | Detected / events | Missed | False alarms / controls | Median delay |
|---:|---|---:|---:|---:|---:|
| 1 | balance_augmented_freeze (shared, sensors 1×, actuator 1×) | 96 / 96 | 0 | 0 / 32 | 0.5 |
| 1 | balance_augmented_freeze (separate_actuator, sensors 1×, actuator 1×) | 96 / 96 | 0 | 0 / 32 | 0.5 |
| 2 | balance_augmented_freeze (shared, sensors 2×, actuator 2×) | 96 / 96 | 0 | 0 / 32 | 0.5 |
| 2 | balance_augmented_freeze (separate_actuator, sensors 2×, actuator 1×) | 96 / 96 | 0 | 0 / 32 | 0.5 |
| 4 | balance_augmented_freeze (shared, sensors 4×, actuator 4×) | 68 / 96 | 28 | 0 / 32 | 0.5 |
| 4 | balance_augmented_freeze (separate_actuator, sensors 4×, actuator 1×) | 94 / 96 | 2 | 1 / 32 | 0.5 |

## Outcomes on matched runs

Fault rows count credited detections. No-fault control rows count false alarms.

| Noise multiplier | Challenge | Both | Shared only | Separate actuator only | Neither |
|---:|---|---:|---:|---:|---:|
| 1 | actuator offset | 32 | 0 | 0 | 0 |
| 1 | common sensor bias | 32 | 0 | 0 | 0 |
| 1 | No-fault control | 0 | 0 | 0 | 32 |
| 1 | primary bias | 32 | 0 | 0 | 0 |
| 2 | actuator offset | 32 | 0 | 0 | 0 |
| 2 | common sensor bias | 32 | 0 | 0 | 0 |
| 2 | No-fault control | 0 | 0 | 0 | 32 |
| 2 | primary bias | 32 | 0 | 0 | 0 |
| 4 | actuator offset | 5 | 0 | 27 | 0 |
| 4 | common sensor bias | 30 | 1 | 0 | 1 |
| 4 | No-fault control | 0 | 0 | 1 | 31 |
| 4 | primary bias | 32 | 0 | 0 | 0 |
