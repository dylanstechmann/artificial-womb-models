# Paired fault detector benchmark

Artificial dimensionless software fixture; no physiological calibration, biological prediction or machine-control output.

Each injected event is a separate run. A detection requires the first confirmation inside the inclusive fault window and strictly before any confirmation in its paired control. All other events count as missed. Delay is measured from onset to confirmation in dimensionless time and summarized only for detections. Each control with any confirmation counts as one false alarm.

For each detector and noise level, multiply each amplitude threshold by the same candidate factor. Select the smallest factor with zero alarms across the calibration controls. If every candidate alarms, use the largest factor and flag the unmet target. The confirmation count stays fixed. Both policies share evaluation seeds and fault timings. Calibration uses separate noise streams and sees only no-fault runs.

Candidate factors were 1, 2, 4, with 12 controls per candidate.

| Noise multiplier | Detector | Detected / events | Missed | False alarms / controls | Median delay |
|---:|---|---:|---:|---:|---:|
| 1 | disagreement_freeze (fixed, 1× thresholds) | 12 / 36 | 24 | 0 / 12 | 0.5 |
| 1 | disagreement_freeze (calibrated, 1× thresholds) | 12 / 36 | 24 | 0 / 12 | 0.5 |
| 1 | balance_augmented_freeze (fixed, 1× thresholds) | 36 / 36 | 0 | 0 / 12 | 0.5 |
| 1 | balance_augmented_freeze (calibrated, 1× thresholds) | 36 / 36 | 0 | 0 / 12 | 0.5 |
| 2 | disagreement_freeze (fixed, 1× thresholds) | 12 / 36 | 24 | 0 / 12 | 0.5 |
| 2 | disagreement_freeze (calibrated, 2× thresholds) | 12 / 36 | 24 | 0 / 12 | 0.5 |
| 2 | balance_augmented_freeze (fixed, 1× thresholds) | 36 / 36 | 0 | 0 / 12 | 0.5 |
| 2 | balance_augmented_freeze (calibrated, 2× thresholds) | 36 / 36 | 0 | 0 / 12 | 0.5 |
| 4 | disagreement_freeze (fixed, 1× thresholds) | 2 / 36 | 34 | 12 / 12 | 0.25 |
| 4 | disagreement_freeze (calibrated, 4× thresholds) | 11 / 36 | 25 | 0 / 12 | 0.5 |
| 4 | balance_augmented_freeze (fixed, 1× thresholds) | 5 / 36 | 31 | 12 / 12 | 0.5 |
| 4 | balance_augmented_freeze (calibrated, 4× thresholds) | 25 / 36 | 11 | 0 / 12 | 0.5 |
